package com.jtmcompany.smartadvertisingboard;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Create_Advertise_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create__advertise_);
    }
}
