package com.jtmcompany.smartadvertisingboard;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.kakao.network.ErrorResult;
import com.kakao.usermgmt.UserManagement;
import com.kakao.usermgmt.callback.LogoutResponseCallback;
import com.kakao.usermgmt.callback.UnLinkResponseCallback;

public class LoginInfo extends AppCompatActivity {
    TextView name_tv;
    TextView profile_tv;
    Button logout_bt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_info);
        name_tv=findViewById(R.id.name);
        profile_tv=findViewById(R.id.profile);
        logout_bt=findViewById(R.id.logout_kakao);

        Intent intent=getIntent();
        String name=intent.getStringExtra("name");
        String profile=intent.getStringExtra("profile");
        name_tv.setText(name);
        profile_tv.setText(profile);


        logout_bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Logout();
            }
        });





    }

    public void Logout(){
        UserManagement.getInstance()
                .requestLogout(new LogoutResponseCallback() {
                    @Override
                    public void onSuccess(Long result) {
                        Toast.makeText(LoginInfo.this, "로그아웃 됬습니다.", Toast.LENGTH_SHORT).show();
                        redirect_login();

                    }

                    @Override
                    public void onCompleteLogout() {
                        Toast.makeText(LoginInfo.this, "로그아웃 됬습니다.2", Toast.LENGTH_SHORT).show();
                    }
                });
    }
    //회원탈퇴
    public void unLink(){
        UserManagement.getInstance().requestUnlink(new UnLinkResponseCallback() {
            @Override
            public void onFailure(ErrorResult errorResult) {
                super.onFailure(errorResult);
                Toast.makeText(LoginInfo.this, "카카오 연결해제 실패", Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onSessionClosed(ErrorResult errorResult) {
                Toast.makeText(LoginInfo.this, "세션이 닫혀있음", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onSuccess(Long result) {
                Toast.makeText(LoginInfo.this, "연결 끊기 성공", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void redirect_login(){
        Intent intent =new Intent(LoginInfo.this,MainActivity.class);
        startActivity(intent);
        finish();
    }

}
