package com.jtmcompany.smartadvertisingboard;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.widget.Toast;

import com.jtmcompany.smartadvertisingboard.Kakao.GlobalApplication;
import com.kakao.auth.ApiErrorCode;
import com.kakao.auth.AuthType;
import com.kakao.auth.IApplicationConfig;
import com.kakao.auth.ISessionCallback;
import com.kakao.auth.KakaoAdapter;
import com.kakao.auth.KakaoSDK;
import com.kakao.auth.Session;
import com.kakao.network.ErrorResult;
import com.kakao.usermgmt.UserManagement;
import com.kakao.usermgmt.callback.MeV2ResponseCallback;
import com.kakao.usermgmt.response.MeV2Response;
import com.kakao.util.exception.KakaoException;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onDestroy() {
        super.onDestroy();

        //새션 콜백 삭제
        Session.getCurrentSession().removeCallback(sessionCallback);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //KakaoSDK.init(new GlobalApplication.KakaoSDKAdapter());

        Session session=Session.getCurrentSession();
        session.addCallback(sessionCallback);
        //checkAndImplicitOpen()는 현재 앱에 유효한 카카오 로그인 토큰이 있다면 바로 로그인을 시켜주는 함수
        session.checkAndImplicitOpen();
        }



    private ISessionCallback sessionCallback= new ISessionCallback() {
        @Override
        public void onSessionOpened() {
            //로그인 세션이 열렸을 때.
            Toast.makeText(MainActivity.this, "로그인 성공", Toast.LENGTH_SHORT).show();
            requstme();
        }

        @Override
        public void onSessionOpenFailed(KakaoException exception) {
            //로그인 세션이 정상적으로 열리지 않았을 때.
            Toast.makeText(MainActivity.this, "로그인 실패", Toast.LENGTH_SHORT).show();
            Log.d("tak","세션 열리지않음");
            Log.d("tak", String.valueOf(exception));
        }

    };


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // 카카오톡|스토리 간편로그인 실행 결과를 받아서 SDK로 전달
        if(Session.getCurrentSession().handleActivityResult(requestCode,resultCode,data)){
            Log.d("tak","reaquestCode: "+requestCode);
            Log.d("tak","resultCode: "+resultCode);
            Log.d("tak","data: "+data);
            return;
        }
    }


    public void requstme(){
        //사용자 정보 요청결과에 대한 Callback
        UserManagement.getInstance().me(new MeV2ResponseCallback() {

            @Override
            public void onFailure(ErrorResult errorResult) {
                //로그인에 실패했을 때. 인터넷 연결이 불안정한 경우도 여기에 해당한다.
                super.onFailure(errorResult);
                int result=errorResult.getErrorCode();
                if(result== ApiErrorCode.CLIENT_ERROR_CODE) {
                    Toast.makeText(MainActivity.this, "네트워크 연결이 불안정합니다. 다시시도해주세요.", Toast.LENGTH_SHORT).show();
                } else{
                    Log.d("tak","로그인 도중 문제생김");
                    Toast.makeText(MainActivity.this, "로그인 도중에 문제가 생겼습니다.", Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onSessionClosed(ErrorResult errorResult) {
                //로그인 도중 세션이 비정상적인 이유로 닫혔을 때
                Toast.makeText(MainActivity.this, "세션이 닫혔습니다. 다시 시도해주세요", Toast.LENGTH_SHORT).show();
                Log.d("tak","세션 닫힘");
                
            }

            @Override
            public void onSuccess(MeV2Response result) {
                //로그인에 성공했을 때
                Log.d("tak","onSuccess");
                Log.d("tak","name: "+result.getNickname());
                Log.d("tak","profile: "+result.getProfileImagePath());
                Log.d("tak","id:  "+result.getId());
                Intent intent=new Intent(getApplicationContext(),LoginInfo.class);
                intent.putExtra("name",result.getNickname());
                intent.putExtra("profile",result.getProfileImagePath());

                startActivity(intent);
                finish();


            }
        });
    }
}
